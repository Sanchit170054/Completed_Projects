// --- Developed By Sanchit --- //

import statistics as stats
import numpy as panda
import matplotlib.pyplot as plt
from scipy.stats.stats import pearsonr

VideoGameTime = [2, 2.5, 3, 1.5, 3.5, 3, 2.5, 2.5, 2, 1.5, 1, 2.5, 2.5, 3.5, 3.5, 3, 3, 2, 1.5, 1, 1.5, 2, 2.5, 3, 3.5]
breakTime = [0.5, 1, 0.5, 0, 1, 1, 0.5, 1, 0.5, 0, 0, 0.5, 1, 0, 1.5, 0.5, 0.5, 0, 0.5, 0, 0.5, 0, 0, 1, 1.5]

meanValue = stats.mean(VideoGameTime)
meanValueb = stats.mean(breakTime)

print("Mean value for playing games is {}".format(meanValue))
print("Mean value for taking break while playing game is {}".format(meanValueb))

print("")

modeValue = stats.mode(VideoGameTime)
print("Mode of the data is {}".format(modeValue))

print("")

medianValue = stats.median(VideoGameTime)
print("Median of the data is {}".format(medianValue))

print("")

deviation = stats.stdev(VideoGameTime, meanValue)
print("Standard Deviation of the data is {}".format(deviation))

print("")

variance = panda.var(VideoGameTime)
print("Variance of the data is {}".format(variance))

print("")

coRelation = pearsonr(VideoGameTime, breakTime)
print("Correlation of the data is")
print(coRelation)






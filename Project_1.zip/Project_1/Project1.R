getmode <- function(v)
{
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

VideoGameTime = c(2, 2.5, 3, 1.5, 3.5, 3, 2.5, 2.5, 2, 1.5, 1, 2.5, 2.5, 3.5, 3.5, 3, 3, 2, 1.5, 1, 1.5, 2, 2.5, 3, 3.5)
breakTime = c(0.5, 1, 0.5, 0, 1, 1, 0.5, 1, 0.5, 0, 0, 0.5, 1, 0, 1.5, 0.5, 0.5, 0, 0.5, 0, 0.5, 0, 0, 1, 1.5)

cat("Mean value for playing games is ", mean(VideoGameTime))
cat("\nMean value for taking break while playing game is ", mean(breakTime))

cat("\n")
cat("\nMode of the data is", getmode(VideoGameTime))
cat("\nMedian of the data is is ", median(VideoGameTime))

cat("\nVariance of the data is", var(VideoGameTime))
cat("\nStandard deviation of the data is", sd(VideoGameTime))
cat("\nVCorrelation of the data is", cor(VideoGameTime, breakTime))


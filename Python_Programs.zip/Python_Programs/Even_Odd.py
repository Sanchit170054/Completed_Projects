num = int(input("Please enter you number"))

if num % 2 == 0:
    print("It's Even..!")
else:
    print("it's Odd...!")

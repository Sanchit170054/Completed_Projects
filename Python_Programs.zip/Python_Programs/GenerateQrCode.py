import pyqrcode
from pyqrcode import QRCode

str = "www.geeksforgeeks.org"

url = pyqrcode.create(str)
url.svg("qr.svg", scale=40)

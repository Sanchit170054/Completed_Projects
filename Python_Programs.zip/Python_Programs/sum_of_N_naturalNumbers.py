upperValue = int(input("Please enter the upper bond of input"))
sum = 0
for i in range(1, upperValue+1):
    sum += i

print("Sum of first {} Natural Number is {}".format(upperValue, sum))
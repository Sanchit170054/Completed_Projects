str = input("Enter you string")

list = []
for i in str:
    if i not in list:
        list.append(i)


print(list)
print(set(str))
print(str[::-1])
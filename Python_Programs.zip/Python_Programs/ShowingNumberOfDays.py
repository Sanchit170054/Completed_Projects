import calendar

year = int(input("Enter the year to whom you want to see calendar"))
month = int(input("Enter the month to whom you want to see calendar (numbers)"))

cal = calendar.month(year, month)
print(cal)

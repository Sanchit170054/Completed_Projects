str1 = input("Please enter the first String")
str2 = input("Please enter the second string")

set1 = set(str1)
set2 = set(str2)

intersection1 = set1.difference(set2)
print(intersection1)
intersection2 = set2.difference(set1)
print(intersection2)

print(list(intersection1) + list(intersection2))

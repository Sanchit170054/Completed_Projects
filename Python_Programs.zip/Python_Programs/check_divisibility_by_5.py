loop = True
while loop:

    try:
        value = int(input("Please enter the number"))
        if value % 5 == 0:
            print("It's divisible by 5")
        else:
            print("Not divisible by 5")
        break

    except:
        print("Please enter an integer value only....!")

    finally:
        print("process is complete...")
list = []

for i in range(0, 3):
    EnterValue = int(input("Please enter your input"))
    list.append(EnterValue)

print("Maximum number is: {}".format(max(list)))

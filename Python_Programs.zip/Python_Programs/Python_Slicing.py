print("Please enter the 5 values")

myList = []
for i in range(1, 6):
    userInput = input("Enter value at {} position ".format(i))
    myList.append(userInput)

print(myList)

reverse = input("Enter the size for reversing")

reverselist = myList[0:len(myList):int(reverse)]
print(reverselist)

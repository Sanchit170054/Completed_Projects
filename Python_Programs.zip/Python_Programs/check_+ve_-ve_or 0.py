

try:
    value = int(input("Please enter any integer value"))

    value = value.__str__()
    firstValue = value[0]

    if firstValue == "-":
        print("You enter negative value")
    elif firstValue == "0":
        print("You enter 0 here")
    else:
        print("you enter positive value")
except:
    print("Please enter integer value only")
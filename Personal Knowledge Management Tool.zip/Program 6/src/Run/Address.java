package Run;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigestSpi;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

import com.sun.javafx.scene.control.skin.ButtonSkin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;

/*******
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: This controller class describes the user interface for the address part and reveals
 *                  some of the new and advance functionality of the address tab</p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-26 </p>
 * 
 * @author Lyn Robert Carter
 * updated author Sanchit
 *  
 * @version 2.03	2018-07-19 Baseline
 * @version 2.10    2018-09-11 A controller class for the contacts part
 * @version 2.17	2018-14-11 A controller class which is enhanced as compared to the 
 * 								previous one in terms of functionality
 * 
 */
	public class Address {
	
	/**********************************************************************************************
	Class Attributes
	**********************************************************************************************/

	// Attributes used to establish the display and control panel within the window provided to us
	private static final double THIS_WINDOW_HEIGHT = Run.WINDOW_HEIGHT;
	private static final double CONTROL_PANEL_HEIGHT = THIS_WINDOW_HEIGHT - 150;
	private static final double THIS_WINDOW_WIDTH = Run.WINDOW_WIDTH;	
	
		
	// These attributes put a graphical frame around the portion of the window that receives the
	// black squares representing alive cells
	private Rectangle rect_outer =  new Rectangle(0,0,THIS_WINDOW_WIDTH, CONTROL_PANEL_HEIGHT-5);
	private Rectangle rect_middle = new Rectangle(5,5,THIS_WINDOW_WIDTH-10, CONTROL_PANEL_HEIGHT-15);
	private Rectangle rect_inner =  new Rectangle(6,6,THIS_WINDOW_WIDTH-12, CONTROL_PANEL_HEIGHT-17);

	// This attribute holds the text that will be displayed 
	private TextArea blk_Text = new TextArea("This is the text for the Contacts");
	
	// Some of the necessary button that we will use at the time of
	// the address tab's various functioning
	private Button button_Add = new Button("Add New Address");
	private Button button_refresh  = new Button("Update Contacts");
	private Button button_search  = new Button("Search Contacts");
	private Button Search_button = new Button("Delete This Address");
	private Button button_edit = new Button("Edit Address");
	private Button Cancel_Button = new Button("Cancel"); 
	private Button button_delete = new Button("Delete Address"); 
	private Button button_Save = new Button("Save this address"); 
	private Button Button_load = new Button("Load the Data"); 
	
	// Some of the necessary label which provides the essential instruction
	// to the user at the time of this tab so that user can work
	// accordingly
	 private Label fileName = new Label("Enter the file Name: ");       
	 private Label Search_Name = new Label("Enter name here: ");   
	 private Label label_name = new Label("Enter name here: ");       
	 private Label messgae = new Label("Your textfield is Editable now...!");    
	 private Label FileFoud = new Label(""); 
	 private Label FIleNotFound = new Label("");
	 private Label message_ErrorDetails = new Label("");
	 
	 
	// Some of the necessary text field where user enter the 
	// input according to the instruction provided by the labels
	 private TextField text_name = new TextField();
	 private TextField textFileName = new TextField();
	 private TextField search_Word = new TextField();
	 
	 
	 private String str_FileName;   // The string that the user enters for the file name
	 private Scanner scanner_Input = null;  // The Scanners used to evaluate whether or not the
	 private String errorMessage_FileContents = ""; // These attributes are used to tell the user, in detail, about errors in the input data
	 
	
	/**********************************************************************************************
	Constructors
	**********************************************************************************************/

	/**********
	 * This constructor established the user interface with all of the graphical widgets that are
	 * use to make the user interface work.
	 * 
	 * @param theRoot	This parameter is the Pane that JavaFX expects the application to use when
	 * 					it sets up the GUI elements.
	 */
	public Address(Pane theRoot){
		
				
		// Set the fill colors for the border frame for the game's output of the simulation
		rect_outer.setFill(Color.LIGHTGRAY);
		rect_middle.setFill(Color.BLACK);
		rect_inner.setFill(Color.WHITE);
		
		// Place a text area into the window and just within the above frame and make it not editable
		setupTextAreaUI(blk_Text, "Monaco", 14, 6, 6, THIS_WINDOW_WIDTH-12, CONTROL_PANEL_HEIGHT-17, false);		

		// Event handling of add button so that when clcik, it will open the popup window for addition
		button_Add.setOnAction((event) -> {	button_delete.setVisible(false);initiateAdding();});
				
		// Some of the properties of the add button explained here
		button_Add.setLayoutX(830);
		button_Add.setLayoutY(450);
		button_Add.setFont(Font.font ("Arial", 16));

		// Event handling of the refresh button which when cliked, refresh the contacts with updated ones
		button_refresh.setOnAction((event) -> {
			try {
				button_refresh.setVisible(false);
				button_edit.setVisible(true);
				button_Add.setVisible(true);
				button_delete.setVisible(true);
				appendAddress();} catch (Exception e) {	e.printStackTrace();}});
		
		// Some of the properties of the refresh button explained here
		button_refresh.setLayoutX(800);
		button_refresh.setLayoutY(530);
		button_refresh.setFont(Font.font ("Arial", 16));
		
		// Some of the properties of the edit button explained here
		button_edit.setLayoutX(650);
		button_edit.setLayoutY(450);
		button_edit.setVisible(false);
		button_edit.setFont(Font.font("Arial", 16));
		
		// Event handling of the edit button so that when user clicked, it makees the textfield editable
		button_edit.setOnAction((event) -> {search_Word.setVisible(false);button_delete.setVisible(false);deleteAddres();});
		
		// Some of the properties of the label Enter file Name
			fileName.setLayoutX(20);
			fileName.setLayoutY(460);
			//final double MAX_FONT_SIZE12 = 18; 
			fileName.setFont(Font.font ("Arial", 18));
			//fileName.setFont(new Font(MAX_FONT_SIZE12));
		
		// Event hadnling of the textfield so that when user enter the text, it will display the message accordingly
		textFileName.textProperty().addListener((observable, oldValue, newValue) -> { checkFileValidation(); });

		// Some of the peroperties of the textfield for the address file
			textFileName.setLayoutX(20);
			textFileName.setLayoutY(490);
			textFileName.setMinWidth(400);
			textFileName.setFont(Font.font ("Arial", 18));

		// implementing some of the properties to save button
			button_Save.setLayoutX(850);
			button_Save.setLayoutY(450);
			button_Save.setVisible(true);
			button_Save.setVisible(false);
			final double MAX_FONT_SIZE3 = 16.0; 
			button_Save.setFont(new Font(MAX_FONT_SIZE3));
			
			
		// Event handling of the load button when clicked, it will load the file 
			// to show the content for address
			Button_load.setOnAction((event) -> { 
				try {ShowContacts();}
				    catch (IOException e) 
						{e.printStackTrace();} });

		// Some of the properties of the load button 
			Button_load.setLayoutX(800);
			Button_load.setLayoutY(490);
			Button_load.setDisable(true);
			Button_load.setFont(Font.font ("Arial", 18));

		// Event handling of the search button so that when clicked, it will
		// search the contacts of that entered person
		button_search.setOnAction((event) -> {
			try {
				button_refresh.setVisible(true);
				button_Add.setVisible(false);
				button_delete.setVisible(false);
				searchstring();} catch (IOException e) {e.printStackTrace();}});
		
		// Some of the properties of the search button
			button_search.setLayoutX(800);
			button_search.setLayoutY(490);
			button_search.setFont(Font.font ("Arial", 16));
		
		// Event handling of the delet button so that when clicked, it will delete 
		// create the popup for the delete
			button_delete.setOnAction((event) -> {search_box();});
		
		// Some of the peoperties of the delete button
			button_delete.setLayoutX(490);
			button_delete.setLayoutY(450);
			button_delete.setFont(Font.font ("Arial", 16));
		
		// make Some of the buttons not visible at the primary state
		// which are in non-use position
			button_refresh.setVisible(false);
			button_search.setVisible(false);
			button_Add.setVisible(false);
			button_delete.setVisible(false);
		
		// Some of the properties of search name label for
			Search_Name.setLayoutX(20);
			Search_Name.setLayoutY(460);
			Search_Name.setFont(Font.font ("Arial", 18));
			Search_Name.setVisible(false);
	
		// Some of the properties for textfield for searhing the word
			search_Word.setLayoutX(20);
			search_Word.setLayoutY(490);
			search_Word.setMinWidth(400);
			search_Word.setFont(Font.font ("Arial", 18));
			search_Word.setVisible(false);

		// Some of the properties for the file found message
			FileFoud.setLayoutX(350);
			FileFoud.setLayoutY(440);
			final double MAX_FONT_SIZE = 18; 
			FileFoud.setFont(new Font(MAX_FONT_SIZE));
			FileFoud.setTextFill(Color.web("Green"));
			 
		// Some of the properties of the error message for file not found
			FIleNotFound.setLayoutX(350);
			FIleNotFound.setLayoutY(450);
			final double MAX_FONT_SIZE1 = 18; 
			FIleNotFound.setFont(new Font(MAX_FONT_SIZE1));
			FIleNotFound.setTextFill(Color.web("Red"));
	 
		// Some of the propeties of the error message
			message_ErrorDetails.setLayoutX(450);
			message_ErrorDetails.setLayoutY(450);
			final double MAX_FONT_SIZE2 = 16; 
			message_ErrorDetails.setFont(new Font(MAX_FONT_SIZE2));
			message_ErrorDetails.setTextFill(Color.web("Red"));
	
		// Place all of the just-initialized GUI elements into the pane with the exception of the
		// Stop button.  That widget will replace the Start button, once the Start has been pressed
		theRoot.getChildren().addAll(rect_outer,button_search, messgae,rect_middle, button_Save,button_delete,rect_inner, 
				blk_Text, button_Add,FileFoud,message_ErrorDetails,search_Word,Search_Name, 
				FIleNotFound,button_refresh,button_edit, fileName, textFileName, Button_load);
		
	}

	/**********************************************************************************************
	Helper methods - Used to set up the JavaFX widgets and simplify the code above
	**********************************************************************************************/

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextAreaUI(TextArea t, String ff, double f, double x, double y, double w, double h, boolean e){
		t.setFont(Font.font(ff, f));
		t.setPrefWidth(w);
		t.setPrefHeight(h);	
		t.setLayoutX(x);
		t.setLayoutY(y);	
		t.setEditable(e);
		t.setWrapText(true);
	}
	
	/**********************************************************************************************
	Action methods - Used cause things to happen during the execution of the application
	**********************************************************************************************/

	/**********
	 * This method reads in the contents of the data file and Once the it is done, the method displays the content 
	 * took to the UI, When clicked on load button
	 * 
	 * @throws IOException exception if file is not writable
	 */
   
	public void ShowContacts() throws IOException {
		
	// off the visisbility of some of the essential items 
		FileFoud.setVisible(false);
		Button_load.setVisible(false);
		textFileName.setVisible(false);
		fileName.setVisible(false);
		button_search.setVisible(true);
		search_Word.setVisible(true);
		Search_Name.setVisible(true);
	
		// using buffer reader to read the file which is input by the user
		  BufferedReader br = new BufferedReader(new FileReader(str_FileName)); 
		  
		  String st;  // declare the string to read the lines
		  while ((st = br.readLine()) != null) 
		  try {
			blk_Text.setText(Address.readFileAsString("Contact.txt")); // display the text in UI after reading the file
		} catch (Exception e) {
			e.printStackTrace();
		}
		  } 

	/**********
	 * This routine checks, after each character is typed, to see if a file of that name is found, it checks to see if the contents conforms
	 * to the specification.
	 * 		If it does, the Load button is enabled and a green message is displayed
	 * 		If it does not, the Load button is disabled and a red error message is displayed
	 *      If a file is not found, a warning message is displayed and the button is disabled.
	 *      If the input is empty, all the related messages are removed and the Load button is disabled.
	 */

	public void checkFileValidation(){
		
		str_FileName = textFileName.getText().trim();			// Whenever the text area for the file name is changed
		if (str_FileName.length()<=0){					// this routine is called to see if it is a valid filename.
			FileFoud.setText("");				// Reset the messages 
			FIleNotFound.setText("");           // to empty
			scanner_Input = null;
		} else 											// If there is something in the file name text area
			try {										// this routine tries to open it and establish a scanner.
				scanner_Input = new Scanner(new File(str_FileName));

				// There is a readable file there... this code checks the data to see if it is valid 
				// for this application (Basic user input errors are GUI issues, not analysis issues.)
				if (fileContentsAreValid()) {
					FileFoud.setText("File found and the contents are valid!");
					message_ErrorDetails.setText("");
					FIleNotFound.setText("");
					Button_load.setDisable(false);
				}
				// If the methods returns false, it means there is a problem with input file
				else {	// and the method has set up a String to explain what the issue is
					FileFoud.setText("");
					FIleNotFound.setText("File found, but the contents are not valid!");
					message_ErrorDetails.setText(errorMessage_FileContents);
					Button_load.setDisable(true);
				}
			} catch (FileNotFoundException e) {			// If an exception is thrown, the file name
				FileFoud.setText("");			// that the button to run the analysis is
				FIleNotFound.setText("File not found!");	// not enabled.
				message_ErrorDetails.setText("");
				scanner_Input = null;	
				//theDictionary = null;
				Button_load.setDisable(true);
			}
	}
	
	/**********
	 * This method reads in the contents of the data file and discards it as quickly as it reads it
	 * in order to verify that the data meets the input data specifications@sid and helps reduce the 
	 * change that invalid input data can lead to some kind of hacking.
	 * 
	 * @return	true - 	when the input file *is* valid
	 * when the input file data is *not* valid - The method also sets a string with
	 * details about what is wrong with the input data so the user can fix it
	 */
		
	public boolean fileContentsAreValid (){
		
		// Declare and initialize data variables used to control the method
		int numberOfLinesInTheInputFile = 0; // This attribute sets the number of lines set during the first read
		String firstLine = "";
		
		// Read in the first line and verify that it has the proper header
		if (scanner_Input.hasNextLine()) {
			firstLine = scanner_Input.nextLine().trim();		// Fetch the first line from the file
			if (firstLine.equalsIgnoreCase("Lynn Robert Carter"))	// See if it is what is expected
				numberOfLinesInTheInputFile = 1;				// If so, count it as one line
			else {												// If not, issue an error message
				return false;									// and return false
			}
		} else {
		// If the execution comes here, there was no first line in the file
			return false;
		}
		
		// Process each and every subsequent line in the input to make sure that none are too long
		while (scanner_Input.hasNextLine()) {
			numberOfLinesInTheInputFile++;						// Count the number of input lines
			
			// Read in the line 
			String inputLine = scanner_Input.nextLine();
			
			// Verify that the input line is not larger than 250 characters...
			if (inputLine.length() > 250) {
				// If it is larger than 250 characters, display an error message on the console
				System.out.println("\n***Error*** Line " + numberOfLinesInTheInputFile + " contains " + 
						inputLine.length() + " characters, which is greater than the limit of 250.");
				
				// Stop reading the input and tell the user this data file has a problem
				return false;
			}
		}
			// Should the execution reach here, the input file appears to be valid
		errorMessage_FileContents = "";							// Clear any messages
		return true;											// End of file - data is valid
	}
	
	
	/**********
	 * This method makes the textfiled editable when click on it and display the relevant message 
	 * at the time of clicking on it. Moreover, it will hide the spome of the controls of the
	 * address.
	 */
	
	private void deleteAddres() {
		
		 // make buttons' visibility off
		Search_Name.setVisible(false);
		button_Add.setVisible(false);
		button_search.setVisible(false);
		
		blk_Text.setEditable(true);  // make the UI editable
		
		// usinfg some of the properties of the message label for display the message
		final double MAX_FONT_SIZE = 18.0; 
		messgae.setFont(new Font(MAX_FONT_SIZE));
		messgae.setLayoutX(650);
		messgae.setLayoutY(490);
		messgae.setTextFill(Color.web("Green"));
	
		// implementing some of the properties to save button
		button_Save.setLayoutX(850);
		button_Save.setLayoutY(450);
		button_Save.setVisible(true);
		final double MAX_FONT_SIZE3 = 16.0; 
		button_Save.setFont(new Font(MAX_FONT_SIZE3));
		
		//evenhandling of the search button which when click, it will call the method to save address
	
		button_Save.setOnAction((event) -> {
			button_delete.setVisible(true);
			search_Word.setVisible(true);
			Search_Name.setVisible(true);
			saveDeleteAddress();});
		}
	
	
	/**********
	 * This method reads in the contents of the data file and Once the it is done, it will display the 
	 * updated contact file whihc display the updated address in the tab
	 */
				
		private void saveDeleteAddress() {
			
			// disable the some of the un-used buttons
			blk_Text.setEditable(false);
			messgae.setVisible(false);
			button_Save.setVisible(false);
			button_Add.setVisible(true);
			button_search.setVisible(true);
			
			try {
		        String newData = blk_Text.getText();  // getting text from the UI
		        String filepath="reContact.txt";  // provideing the path for writting
		          
		        // write the updated file 
		          PrintWriter out = new PrintWriter(new FileOutputStream(filepath));
				  out.write(newData);
		          out.close();
		
		        } catch (IOException e) {
		
		            e.printStackTrace();
		        }
		}

		/**********
		 * This method reads the updated contact file and then at the time of running the program
		 * it will initiately display the addresses on UI.
		 * @param Strig fileName gives the path ofthe file
		 * 
		 * @throws Exception invalid exception has been thrown
		 */
			
		public static String readFileAsString(String fileName)throws Exception 
		{ 
		
		 String data = ""; 
		 data = new String(Files.readAllBytes(Paths.get(fileName))); 
		 return data; 
		} 
	
		public void appendAddress() throws Exception  {
			blk_Text.setText("");
			 String data = readFileAsString("Contact.txt"); 
			 blk_Text.appendText(data.trim());
		
		}
	
		/**********
		 * This method calls when we clcik on the delete button as on clicking, it will display the
		 * popup window which have one textfiled for enter the name of the person whom you want to delete
		 * 
		 */
		
		public void search_box() {
			
			 Stage theStage = new Stage();			
			 
		    //Creating a Grid Pane 
		      GridPane gridPane = new GridPane();    
		      
		      //Setting size for the pane 
		      gridPane.setMinSize(500, 300); 
		      
		      //Setting the padding  
		      gridPane.setPadding(new Insets(10, 10, 10, 10)); 
		      
		      //Setting the vertical and horizontal gaps between the columns 
		      gridPane.setVgap(5); 
		      gridPane.setHgap(5);       
		      
		      //Setting the Grid alignment 
		      gridPane.setAlignment(Pos.CENTER); 
		       
		      //Arranging all the nodes in the grid 
		 //     gridPane.add(text1, 0, 0); 
		  //    gridPane.add(textField1, 1, 0); 
		      gridPane.add(label_name, 1, 1);
		      gridPane.add(text_name, 1, 2);
		      text_name.setMinWidth(300);
		      
		      gridPane.add(Search_button, 1, 9); 
		      gridPane.add(Cancel_Button, 2, 9);
		      	     	      
		      //Creating a scene object 
		      Scene scene = new Scene(gridPane); 
		       
		      //Setting title to the Stage 
		      theStage.setTitle("Delete Contact"); 
		         
		      //Adding scene to the stage 
		      theStage.setScene(scene);
		      
		      //Displaying the contents of the stage 
		      theStage.show(); 
		      
		      // Event handling of the button whihc when clikced, call the method delete to
		      //actually delete the contact address
		      
		      Search_button.setOnAction((event) -> {
		    	  try {		    		  
						delete();
						theStage.hide();} catch (FileNotFoundException e) {e.printStackTrace();
						} catch (IOException e) {e.printStackTrace();}});
		      
		      // button whihc when press, hide the popup window
		       Cancel_Button.setOnAction((event) -> {theStage.hide();});
		       }

		/**********
		 * This method reads in the contents of the data file and and when click on the search button
		 * this method calls which read and find the name of the string and then show that 
		 * address to the UI as a result
		 */
		
			public void searchstring() throws IOException {
				
				// Make some of the button disable
					button_edit.setVisible(false);
					button_Add.setVisible(true);
			  		button_delete.setVisible(true);
			  		button_edit.setVisible(true);
			  		
				int n = 50;
				for(int i = 1; i<n; i++)
				{
			
			        FileReader fr = new FileReader("Contact.txt");  // using filereader to read the file and then
			        BufferedReader br = new BufferedReader(fr);  // buffer reader to append it
			        String s;
			        String keyword = search_Word.getText();  // after that get the text from the textfield
			      
			        while ((s=br.readLine())!=null) {   // check if the word is exist
			            if(s.contains(keyword)) { // if yes, the read it
			            
			            	// then again read the other four lines from that particulr string
			                String nextLine = br.readLine();
			                String nextLine1 = br.readLine();     
			                String nextLine2 = br.readLine(); 
			                String nextLine3 = br.readLine(); 
			                
			                // used to display the output into the format and on UI
			               blk_Text.setText(search_Word.getText() +"\n"+ nextLine +"\n"+ 
		                                      nextLine1 +"\n"+ nextLine2 +"\n"+ nextLine3);
			            } }
			        
				}search_Word.setText("");
				}

			
			/**********
			 * This method reads in the contents of the text field and then find the particular string into the file
			 * after that, clicking on delte button, it will remove the contact and re write the updated file.
			 * 
			 * @throws IOException if file is not writable
			 */
				
			public void delete() throws IOException {
				
				 FileReader fr = new FileReader("Contact.txt");  // use filereader to read the file
			        BufferedReader br = new BufferedReader(fr);  // then append it with the help of buffer reader
			        
			        // declaring the various strings
			        String delete;
			        String task="";
			        byte []tasking;
			        while ((delete = br.readLine()) != null) { 	//check to see whether the string is present in the line
			            if (delete.startsWith(text_name.getText())) { // if so, read it and 
			          
			            	// then deletlines and other four lines from that string
			            	delete.startsWith(br.readLine());
			            	delete.startsWith(br.readLine());
			            	delete.startsWith(br.readLine());
			            	delete.startsWith(br.readLine());
			            	continue;
			            }
			            task+=delete+"\n"; // update the values of the array
			        }
			      
			        // write the file with the help of buffer writer 
			        BufferedWriter writer = new BufferedWriter(new FileWriter("Contact.txt"));
			        writer.write(task.trim());
			        br.close();
			        writer.close();
			        blk_Text.setText(task.trim());  // display the file on UI
			      }

			/**********
			 * This method calls as click on the add button, as clciked it will open the popup so 
			 * that user can enter in the various field to add the address into the file
			 */
					
			private void initiateAdding(){
				
				// create the stage and add declare some of the various 
				// labesls and texfield
			      Stage theStage = new Stage();			
			      Label label_name = new Label("Name: ");       
			      TextField text_name = new TextField();
			      Label label_address = new Label("Address: "); 
			      TextField text_address = new TextField();
			      Label label_pincode = new Label("Phone Number: ");
			      TextField text_pincode= new TextField();
			      Label label_country = new Label("E-Mail Address: ");
			      TextField text_country= new TextField();
			      
			      //Creating Buttons for the funcionality of the saving the address
			      Button Save_button = new Button("Save This Address"); 
			      Button Cancel_Button = new Button("Cancel");  
			      
			      //Creating a Grid Pane 
			      GridPane gridPane = new GridPane();    
			      
			      //Setting size for the pane 
			      gridPane.setMinSize(500, 300); 
			      
			      //Setting the padding  
			      gridPane.setPadding(new Insets(10, 10, 10, 10)); 
			      
			      //Setting the vertical and horizontal gaps between the columns 
			      gridPane.setVgap(5); 
			      gridPane.setHgap(5);       
			      
			      //Setting the Grid alignment 
			      gridPane.setAlignment(Pos.CENTER); 
			       
			      //Arranging all the nodes in the grid 
			      // so that it will display the elements into the grid
			      gridPane.add(label_name, 0, 1);
			      gridPane.add(text_name, 1, 1); 
			      gridPane.add(label_address, 0, 2); 
			      gridPane.add(text_address, 1, 2); 
			      gridPane.add(label_pincode, 0, 4); 
			      gridPane.add(text_pincode, 1, 4); 
			      gridPane.add(label_country, 0, 6); 
			      gridPane.add(text_country, 1, 6);
			      gridPane.add(Save_button, 1, 9); 
			      gridPane.add(Cancel_Button, 2, 9); 
			       
			      //Creating a scene object 
			      Scene scene = new Scene(gridPane); 
			       
			      //Setting title to the Stage 
			      theStage.setTitle("Add Contact"); 
			         
			      //Adding scene to the stage 
			      theStage.setScene(scene);
			      
			      //Displaying the contents of the stage 
			      theStage.show(); 
		
			      //event handling of the cancel button so that as press, it will
			      // hide the popup
			      
			      Cancel_Button.setOnAction((event) -> { 
			    	  button_delete.setVisible(true);
			    	  theStage.hide(); });
			           
			      // this button help the user to save the address into the 
			      // Contact file
			      Save_button.setOnAction((event) -> { 
			    	  
			    	  button_refresh.setVisible(true);
			    	  button_edit.setVisible(false);
					 
			    	  	String FILENAME = "Contact.txt";
			    	  	
			    	  	// creating the buffer writer for each column
						BufferedWriter bw_name = null;
						BufferedWriter bw_address = null;
						BufferedWriter bw_pincode = null;
						BufferedWriter bw_country = null;
						
						// creating the file writer for each column
						FileWriter fw_name = null;
						FileWriter fw_address = null;
						FileWriter fw_pincode = null;
						FileWriter fw_country = null;

						try {
							// fetching the text from the each textfile in the add window popup
							String data_name = "\n"+text_name.getText()+",";
							String data_address = "\n"+text_address.getText()+",";
							String data_pincode = "\n"+text_pincode.getText()+",";
							String data_country = "\n"+text_country.getText()+"\n" +"----------";
							
							File file = new File(FILENAME);
		
							// if file doesnt exists, then create it
							if (!file.exists()) {
								file.createNewFile();
							}
		
							// if comes true, then it will append the data
							fw_name = new FileWriter(file.getAbsoluteFile(), true);
							fw_address = new FileWriter(file.getAbsoluteFile(), true);
							fw_pincode= new FileWriter(file.getAbsoluteFile(), true);
							fw_country = new FileWriter(file.getAbsoluteFile(), true);
							
							// useing buffer writer to append the data from the file writer
							bw_name = new BufferedWriter(fw_name);
							bw_address = new BufferedWriter(fw_address);
							bw_pincode = new BufferedWriter(fw_pincode);
							bw_country = new BufferedWriter(fw_country);
		
							// writing the updated data into the contacts file and update it
							bw_name.write(data_name);
							bw_address.write(data_address);
							bw_pincode.write(data_pincode);
							bw_country.write(data_country);
			
							theStage.show(); 
							theStage.hide();
							theStage.close();
		
						} catch (IOException e) {
		
							e.printStackTrace();
		
						} finally {try {
										
									// after all this, if all the filed are not null
							// then it will close all the writers and enter the data into file
											if (bw_name != null)bw_name.close();
											if (fw_name != null)fw_name.close();
											
											if (bw_address != null)bw_address.close();
											if (fw_address != null)fw_address.close();
										
											if (bw_pincode != null)bw_pincode.close();
											if (fw_pincode != null)fw_pincode.close();
											
											if (bw_country != null)bw_country.close();
											if (fw_country != null)fw_country.close();
				
											} catch (IOException ex) {ex.printStackTrace();}} });
							}
			}
package Run;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import CorrespondingFiles.TodoList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;

/*******
 * <p> Title: UserInterfaceOfContacts Class. </p>
 *
 * <p> Description: A JavaFX demonstration application: THis class reveals the various fields and functionlity of the todo items
 * 					and notes section along with their functionlities </p>
 *
 * <p> Copyright: Lynn Robert Carter © 2018-08-26 </p>
 *
 * @author Lynn Robert Carter 
 * updated author Sanchit
 *
 * @version 2.03    2018-07-19 Baseline
 * @version 2.10	2018-08-26 A simple spare tab which is note in use
 * @version 2.17	2018-14-11 A controller class which controls the functionality of the
 * 								spare, now it is called todo items/ notes tab
 */
public class ToDo_Notes {

	
        /**********************************************************************************************

        Class Attributes

         **********************************************************************************************/

        // Attributes used to establish the display and control panel within the window provided to us
        private static final double THIS_WINDOW_HEIGHT =Run.WINDOW_HEIGHT;
        private static final double CONTROL_PANEL_HEIGHT = THIS_WINDOW_HEIGHT - 180;
        private static final double THIS_WINDOW_WIDTH =Run.WINDOW_WIDTH;

        // These attributes put a graphical frame around the portion of the window 
        private Rectangle rect_outer =  new Rectangle(0,0,THIS_WINDOW_WIDTH,CONTROL_PANEL_HEIGHT-5);
        private Rectangle rect_middle = new Rectangle(5,5,THIS_WINDOW_WIDTH-10, CONTROL_PANEL_HEIGHT-15);
        private Rectangle rect_inner =  new Rectangle(6,6,THIS_WINDOW_WIDTH-12, CONTROL_PANEL_HEIGHT-17);
        
        // This attribute holds the text that will be displayed
        private TextArea blk_Text2 = new TextArea();
        
        //creating the radio buttons for notes and todo
        private RadioButton button_Notes = new RadioButton("Notes"); 
        private RadioButton button_ToDo = new RadioButton("To-Do");
        
        // creating teh various text field and labels for intructions
        private Label label_name2 = new Label("Enter your Item Here: ");       
   	    private TextField text_name2 = new TextField();
   	    private Label messgae = new Label("Your Textfield is editable now..! "); 
   	    
   	    // creating the various buttons for their further use
	   	 private Button button_save = new Button("Save");
	   	 private Button Add_button = new Button("Add this Item"); 
		 private Button Cancel_Button = new Button("Cancel");  
		 private Button refresh = new Button("View To Do Items");
		 private Button Btn_remove = new Button("Remove this Item");
		 
		 // creating the todo list here to save all the todo items
		 TodoList list = new TodoList();
	 
        /**********************************************************************************************
 		Constructors
        **********************************************************************************************/

        /**********
         * This constructor established the user interface with all of the graphical widgets that are
         * use to make the user interface work.
         *
         * @param theRoot    This parameter is the Pane that JavaFX expects the application to use when
         *                    it sets up the GUI elements.
         */
        public ToDo_Notes(Pane theRoot) {

                // Set the fill colors for the border frame for the game's output of the simulation
                rect_outer.setFill(Color.LIGHTGRAY);
                rect_middle.setFill(Color.BLACK);
                rect_inner.setFill(Color.WHITE);

                // Place a text area into the window and just within the above frame and make it not editable
                  setupTextAreaUI(blk_Text2, "Monaco", 14, 6, 6, THIS_WINDOW_WIDTH-12, CONTROL_PANEL_HEIGHT-17, true);
            
                 // using some of properties for the notes button
                button_Notes.setLayoutX(50);
                button_Notes.setLayoutY(450);
                final double MAX_FONT_SIZE1 = 18.0; 
    			button_Notes.setFont(new Font(MAX_FONT_SIZE1));
                 
    			// Setup the refresh button which is pressed by the user to search the word
    			   setupButtonUI(refresh, "Arial", 18, 120, Pos.BASELINE_LEFT, Run.WINDOW_WIDTH - 450,CONTROL_PANEL_HEIGHT + 60);
                
    			   //Even hadnling of the remove button which when presed, it will call the delete method
                Btn_remove.setOnAction((event) -> { try {deleteTodo();} catch (IOException e) {e.printStackTrace();	}});
                
                //Evnet handling of the refresh button which when press, it will update the todo items
                refresh.setOnAction((event) -> {
                	try {
                		// disbaling some of the non-use buttons
	                	button_Notes.setVisible(true);
	                	button_Notes.setSelected(false);
	                	button_ToDo.setVisible(true);
	                	blk_Text2.setEditable(false);
	                	button_save.setVisible(false);
	                	
						appendTodo();} catch (Exception e) {e.printStackTrace();	} });
                            
                
                // make the visibility off to the some of buttons
                refresh.setVisible(false);
                button_save.setVisible(false);
                messgae.setVisible(false);
                                
                // Setup the Load button to load the file which display the diction in the window and console
                setupButtonUI(button_save, "Arial", 18, 120, Pos.BASELINE_LEFT, Run.WINDOW_WIDTH - 1000, CONTROL_PANEL_HEIGHT + 60);

                // event handling of the save button which when pressed call the save method 
                button_save.setOnAction((event) -> {
                	// disbale some of the irrelavant buttons
                button_Notes.setVisible(false);
                refresh.setVisible(true);save(); });
                
                // implementing some of the properties of the button save
                button_save.setLayoutX(50);
                button_save.setLayoutY(500);
              
                // Event handling of the notes button to initiate the notes method
                button_Notes.setOnAction((event) -> {
                
                // disbale some of the unimportant buttons
                blk_Text2.setEditable(true);
                button_save.setVisible(true);
                button_ToDo.setVisible(false);
                initiateNotes();});

       
                // EVent handling todo buttons which when pressed call the todo method for its functioning 
                button_ToDo.setOnAction((event) -> {
                	
                	// disbale the unimportant buttons
                	refresh.setVisible(true);
                	messgae.setVisible(false);
                	button_save.setVisible(false);
                	blk_Text2.setEditable(false);
                	 
                	 try {initiatetodo();} catch (Exception e) {e.printStackTrace();}});
        
		        // using some of the properties for the refresh button
		        refresh.setLayoutX(800);
		        refresh.setLayoutY(500);

				    // Using some of the properties for the todo buttons
		            button_ToDo.setLayoutX(800);
		            button_ToDo.setLayoutY(450);
		            final double MAX_FONT_SIZE = 18.0; 
					button_ToDo.setFont(new Font(MAX_FONT_SIZE));
	            
           
                // Place all of the just-initialized GUI elements into the pane
                theRoot.getChildren().addAll(rect_outer, rect_middle, rect_inner,button_ToDo, button_Notes,
                				button_save,blk_Text2,messgae,refresh);
        }
      
		

		/**********************************************************************************************

        Helper methods - Used to set up the JavaFX widgets and simplify the code above

         **********************************************************************************************/

        /**********
         * Private local method to initialize the standard fields for a text field
         */
        private void setupTextAreaUI(TextArea t, String ff, double f, double x, double y, double w, double h, boolean e){
                t.setFont(Font.font(ff, f));
                t.setPrefWidth(w);
                t.setPrefHeight(h);     
                t.setLayoutX(x);
                t.setLayoutY(y);        
                t.setEditable(e);
                t.setWrapText(true);
        }

        /**********
         * Private local method to initialize the standard fields for a button
         */
        private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
                b.setFont(Font.font(ff, f));
                b.setMinWidth(w);
                b.setAlignment(p);
                b.setLayoutX(x);
                b.setLayoutY(y);                
        }

        
        /**********************************************************************************************
        Action methods - Used cause things to happen during the execution of the application
        **********************************************************************************************/
       
    	/**
		 * This method reads the updated todo file and then at the time of running the program
		 * it will initiately display the addresses on UI.
		 * 
		 * @param fileName gives the path of the file
		 * @return data provide data by reading the file
		 * @throws Exception throws the exception
		 */
			        
        public static String readFileAsString(String fileName)throws Exception 
       	{ 
       	 String data = ""; 
       	 data = new String(Files.readAllBytes(Paths.get(fileName))); 
       	 return data; 
       	} 
       
        public void appendTodo() throws Exception  {
     
    		 String data = new String(Files.readAllBytes(Paths.get("Repository Folder\\To Do List.txt")));
    		 blk_Text2.setText(data);
    	
        }
         
        /**
		 * This method reads the updated notes file and then at the time selection for teh notes button
		 * it will display the data from the file
		 * 
		 * @param fileName gives the path of the file
		 * @return data provide data by reading the file
		 * @throws Exception throws the exception
		 */
        public static String readFileAsStringforNotes(String fileName)throws Exception 
       	{
       	 String data = ""; 
       	 data = new String(Files.readAllBytes(Paths.get(fileName))); 
       	 return data; 
       	} 
       
        public void appendNotes() throws Exception  {
     
    		 String data = new String(Files.readAllBytes(Paths.get("Repository Folder\\Notes.txt")));
    		 blk_Text2.appendText(data);
    	  }
         
        /**
		 * This method as called, it will open the popup window so that user can enter the
		 * to do item there
		 * 
		 * @throws Exception throws exceprion here
		 */
        
        public void initiatetodo() throws Exception {
        	
        	button_Notes.setSelected(false);
        	appendTodo();  // caling the method to read the updated file
        	
        	refresh.setVisible(false);
        	 Stage theStage = new Stage();			
    		 
     	    //Creating a Grid Pane 
     	      GridPane gridPane = new GridPane();    
     	      
     	      //Setting size for the pane 
     	      gridPane.setMinSize(500, 300); 
     	      
     	      //Setting the padding  
     	      gridPane.setPadding(new Insets(10, 10, 10, 10)); 
     	      
     	      //Setting the vertical and horizontal gaps between the columns 
     	      gridPane.setVgap(5); 
     	      gridPane.setHgap(5);       
     	      
     	      //Setting the Grid alignment 
     	      gridPane.setAlignment(Pos.CENTER); 
     	       	
     	      gridPane.add(label_name2, 1, 0);
     	      gridPane.add(text_name2, 1, 2);
     	      text_name2.setText("");
     	      text_name2.setMinWidth(350);
     	      
     	      gridPane.add(Add_button, 1, 9); 
     	      gridPane.add(Cancel_Button, 2, 11); 
     	      gridPane.add(Btn_remove, 2, 9); 
    	      
     	      //Creating a scene object 
     	      Scene scene = new Scene(gridPane); 
     	       
     	      //Setting title to the Stage 
     	      theStage.setTitle("To Do Items"); 
     	         
     	      //Adding scene to the stage 
     	      theStage.setScene(scene);
     	      
     	      //Displaying the contents of the stage 
     	      theStage.show(); 
   	    
     	      //event handling of the button so that at the time of press, it will add the items into the file 
     	      //as weel as display it on the UI
     	     Add_button.setOnAction((event) -> {
     	    	 try {AddThisItem();} catch (IOException e) {e.printStackTrace();} });
     	     
     	     // at its time , it will hide the popup window
     	    Cancel_Button.setOnAction((event) -> {theStage.hide();}); 
        }

        /**
		 * This method reads the updated todo file and then at then add the word written on
		 * the textfield in the add todo popup into the file.
		 */
        
        private void AddThisItem() throws IOException {
        	
        	blk_Text2.appendText(blk_Text2.getText());  //append the data from the UI
        	
        	try {appendTodo();
			} catch (Exception e) {
				e.printStackTrace();
			}
        	
        	String filepath = "Repository Folder\\To Do List.txt";  //provideing the valid path of the file
        	list.add(text_name2.getText()); // add the items in the list 
        	
        	FileReader fileReader =  new FileReader(filepath);  // read the file and append it wiht
        	 BufferedReader bufferedReader = new BufferedReader(fileReader);   // buffer reader
        	 	 				
			blk_Text2.setText(list.toString()); // put the added item in the UI
			
			PrintWriter out = new PrintWriter(new FileOutputStream(filepath));  // write the file with the updated contents
			String data = new String(Files.readAllBytes(Paths.get("Repository Folder\\To Do List.txt")));
			out.write(data);  // write the data into the file
			out.write(list.toString());
			out.flush();
			out.close();
			
			// at last, after one item blank the field
			text_name2.setText("");
		}
       
        /**
		 * This method will remove the todo items at the time when button is clicked
		 */
        
        private void deleteTodo() throws IOException {
        	
        	String filepath = "Repository Folder\\To Do List.txt";  // providding the path for file
        	 String removed = list.remove(list.getSize());  // remove the item form the list
      
        	 blk_Text2.setText(list.toString()); // display the updated list on UI

        	 PrintWriter out = new PrintWriter(new FileOutputStream(filepath)); // using it to wrtie the file
        	 out.write(list.toString());  // write the updated list into the file
        	 out.flush();
        	 out.close();
          }
   
        /**
		 * This method when calls, it will make the textfield editable and then display the message to aware the user
		 * for edit the data.
		 */
		public void initiateNotes() {
		
			//make some of the buttons visible
			refresh.setVisible(true);
			button_ToDo.setSelected(false);
			button_ToDo.setVisible(true);
			
			// implementing some of the properties for message label 
			final double MAX_FONT_SIZE = 25.0; 
			messgae.setFont(new Font(MAX_FONT_SIZE));
			messgae.setLayoutX(250);
			messgae.setLayoutY(450);
			messgae.setTextFill(Color.web("Green"));
			messgae.setVisible(true);
			
			blk_Text2.setText("");
			blk_Text2.setText(blk_Text2.getText());
			
			// call the append method to display the updated notes
			try {
				appendNotes();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		/**
		 * This method will save the updated notes done by the user and save it to the file
		 * by getting the data from the text field
		 */
		
		private void save() {
			
			//make the visibility off to some buttons
			button_Notes.setVisible(true);
			button_save.setVisible(false);
			try {
				messgae.setVisible(false);
				blk_Text2.setEditable(false);
				        String newData = blk_Text2.getText(); // extract the data from the UI
				        
				        String filepath="Repository Folder\\Notes.txt"; // providing path of the file
				          
				        //use the printwriter to write the updaed data
				          PrintWriter out = new PrintWriter(new FileOutputStream(filepath));
						   out.write(newData); // wrting the data from the UI
				           out.close();
				        } catch (IOException e) { e.printStackTrace(); }
		}
		 
}
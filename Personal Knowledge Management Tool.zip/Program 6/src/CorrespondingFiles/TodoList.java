package CorrespondingFiles;

/**
 * Provides a very simple ToDoList.  New items can be added at the end
 * and removed from any other position.  ToDoList tasks are indexed
 * starting at 1 (not 0).
 * <p>
 * Demonstrates use of arrays and object-oriented programming (OOP).
 *
 * @author Zach Tomaszewski
 */
public class TodoList {

  //instance variables
  private String[] todo; //storage of tasks
  private int count;     //how many tasks have been added to todo


  /**
   *  Builds a new, empty ToDoList.  Current max capacity is 5.
   */
  public TodoList() {
    this.todo = new String[10];
    this.count = 0;
  }

  /**
   * Adds the given item to this ToDoList.  Returns true if successfully
   * added, or false if not (such as when the list is full).
   * @param String item - add the content from the textfield
   * @return true if list is not full, it will give true
   */
  public boolean add(String item) {
    if (this.count == this.todo.length) {
      return false;  //can't add to full list
    }else {
      this.todo[count] = item;
      this.count++;
      return true;
    }
  }

  /**
   * Returns how many items are currently stored in this list.
   * @return count give the number of items from the list
   */
  public int getSize() {
    return count;
  }

  /**
   * Removes the item at the given 1-based index in this list.
   * Returns the removed item, or null if the given index did not correspond
   * to a valid item.
   * @param index give the index of the particular item
   * @return deleted delete the item by using its index
   */
  public String remove(int index) {
    if (index < 1 || index > this.count) {
      return null;  //no such element
    }else {
      index--;  //convert to 0-based indexing used by array
      String deleted = this.todo[index];
      //delete by shifting everything down into removed item's space
      for (int i = index; i < this.count - 1; i++) {
        this.todo[i] = this.todo[i + 1];
      }
      this.count--;  //removed an element
      return deleted;
    }
  }

  /**
   * Returns a String representation of this ToDoList.
   * Specifically, "TODO:" followed by a numbered list of tasks.
   */
  public String toString() {
    String output = "ToDo Item:\n";
    for (int i = 0; i < this.count; i++) {
      output += (i + 1) + ". " + this.todo[i] + "\n";
    }
    return output;
  }
 
}
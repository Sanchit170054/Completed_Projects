package dataAnalyzer;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sun.javafx.collections.MappingChange.Map;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ComboBoxBase;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/*******
 * <p> Title: EffortLogger User Interface Class. </p>
 * 
 * <p> Description: Effort Log Entry Screen </p>
 * 
 * <p> Copyright: Rajeev Gupta � 2018 </p>
 * 
 * @author Rajeev Gupta
 * 
 * @version 1.00	28-04-2018 The mainline of a JavaFX-based GUI implementation of an Effort Logger Analysis
 * 
 */
public class EffortLogUserInterface {
	
	
	/* Constants used to parameterize the graphical user interface.  We do not use a layout manager for
	   this application. Rather we manually control the location of each graphical element for exact
	   control of the look and feel. */
	
	public final static double WINDOW_WIDTH = 500;
	public final static double WINDOW_HEIGHT = 600;
	
	/*********************************************************************
	             Attributes
	*********************************************************************/
	
	/***********************************************************************************
	 These are the application Label UI controls for Header Message, Name of faculty,
	 Staff Id, Course,Day, Week No, Hours spend, Activity, Graded What, Deliverable Type, 
	 No. of files graded and size, required by the user interface	
	***********************************************************************************/
	Label lblHead = new Label("Data Analyzer ");                 
	Label lblFaculty = new Label();              
	Label lblStaffId = new Label();              
	Label lblCourse = new Label();               
	Label lblDay = new Label();
	Label lblWeekNo = new Label();
	Label lblHours = new Label();
	Label lblActivity = new Label();
	Label lblGradedWhat = new Label();
	Label lblDeliverableType = new Label();
	Label lblNoOfFile = new Label();
	Label lblSize = new Label();
	
	Button btn_Back = new Button("Back");
	Button btn_SaveRecord = new Button("Save Record");	
	/***********************************************************************************
	* These are the application ComboBox UI controls for Course Name, Hours spend, Activity 
	* done, Graded What and Deliverable Type, required by the user interface	
	***********************************************************************************/
	
	// Code to define various Combo Boxes.
	
	ComboBox <String> Course_Name = new ComboBox<String>();
	ComboBox <String> Hours_spend= new ComboBox<String>();
	ComboBox <String> Activity = new ComboBox<String>();
	ComboBox <String> Graded_What = new ComboBox<String>();
	ComboBox <String> Deliverable_Type= new ComboBox<String>();
	
	
	
	// Code to define various TextField, DatePicker controls
	
	TextField text_StaffId = new TextField("150012");
	TextField text_Day = new TextField();
	TextField text_WeekNo = new TextField();
	TextField text_Hours = new TextField();
	TextField text_NoOfFile = new TextField();
	TextField text_Size = new TextField();
	TextField text_Faculty = new TextField("Dr. Rajeev Gupta");
	
	DropShadow ds = new DropShadow();       // DropShadow object ds to set the background shadow of various control
		
	
	
	/**********
	 * This constructor initializes all of the elements of the graphical user interface. These assignments
	 * determine the location, size, font, color, and change and event handlers for each GUI object.
	 * @throws FileNotFoundException 
	 */
	
	public EffortLogUserInterface(Pane theRoot,String uname) throws FileNotFoundException {
		
	
		
		/*********************************************************************
		* This code is used to define the Offset value and Color for Shadow
		**********************************************************************/
	
		
		ds.setOffsetY(3.0f);
		ds.setColor(Color.color(0.4f, 0.4f, 0.4f));
		
		// code to set an image (mmu.jpg) as logo on specific position
		
		Image logo = new Image(new FileInputStream("mmu.jpg"));
		ImageView logo_imView = new ImageView(logo);

		logo_imView.setLayoutX(10);
		logo_imView.setLayoutY(10);
		logo_imView.setFitHeight(200);
		logo_imView.setFitWidth(180);

		
		// Setup various UI controls on GUI		
				
		DatePicker datePicker = new DatePicker();
		
		datePicker.setLayoutX(250); datePicker.setLayoutY(180);
		datePicker.setValue(LocalDate.parse(new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime()), DateTimeFormatter.ofPattern("dd-MM-yyyy")));
		datePicker.setLayoutX(450); datePicker.setLayoutY(240);
		
		
		setupLabelUI(lblHead,"Effort Log Form", "Arial", 24, WINDOW_WIDTH/1-180, 20);
		lblHead.setEffect(ds);
		
		setupLabelUI(lblFaculty,"Faculty Name", "Arial", 20, WINDOW_WIDTH/2-50, 120);
		lblFaculty.setEffect(ds);
		setupTextUI(text_Faculty, "Arial", 18, WINDOW_WIDTH/2-90, 330, 120, false);
		lblFaculty.setEffect(ds);
		
		setupLabelUI(lblStaffId,"Staff ID", "Arial", 20, WINDOW_WIDTH/1-3, 120);
		lblStaffId.setEffect(ds);
		setupTextUI(text_StaffId, "Arial", 20, WINDOW_WIDTH/2-98, 600, 120, false);
		lblStaffId.setEffect(ds);
				
		setupLabelUI(lblCourse,"Course Name", "Arial",20, WINDOW_WIDTH/2-50, 200);
		lblCourse.setEffect(ds);
		
		setupLabelUI(lblDay,"Day", "Arial",20, WINDOW_WIDTH/2-50, 240);
		lblDay.setEffect(ds);
				
		setupLabelUI(lblWeekNo,"Week No.", "Arial", 20, WINDOW_WIDTH/2-50, 280);
		lblWeekNo.setEffect(ds);
		setupTextUI(text_WeekNo, "Arial", 20, WINDOW_WIDTH/2-50, 450, 280, true);
		lblWeekNo.setEffect(ds);
		
		setupLabelUI(lblHours,"Hours", "Arial", 20, WINDOW_WIDTH/2-50, 320);
		lblHours.setEffect(ds);
		
		setupLabelUI(lblActivity,"Activity", "Arial", 20, WINDOW_WIDTH/2-50, 360);
		lblActivity.setEffect(ds);
		
		setupLabelUI(lblGradedWhat,"Grade What", "Arial", 20, WINDOW_WIDTH/2-50, 400);
		lblGradedWhat.setEffect(ds);
		
		setupLabelUI(lblDeliverableType,"how many Deliv Files", "Arial", 20, WINDOW_WIDTH/2-50, 440);
		lblDeliverableType.setEffect(ds);
	
		setupLabelUI(lblNoOfFile,"No Of File", "Arial", 20, WINDOW_WIDTH/2-50, 480);
		lblNoOfFile.setEffect(ds);
		setupTextUI(text_NoOfFile, "Arial", 20, WINDOW_WIDTH/2-50, 450, 480, true);
		lblNoOfFile.setEffect(ds);
		
		setupLabelUI(lblSize,"Size", "Arial", 20, WINDOW_WIDTH/2-50, 520);
		lblSize.setEffect(ds);
		setupTextUI(text_Size, "Arial", 20, WINDOW_WIDTH/2-50, 450, 520, true);
		lblSize.setEffect(ds);
		
		
		setupButtonUI(btn_Back, "Symbol", 24, 600, 600);
		btn_Back.setOnAction((event) -> {((Stage)theRoot.getScene().getWindow()).close();});
		btn_Back.setEffect(ds);
		

		Course_Name.getItems().addAll("COmm II","Calc II","App Dev","Physiscs II","SWT&T");
		Course_Name.setLayoutX(450); Course_Name.setLayoutY(200);
		
		Hours_spend.getItems().addAll("0.5","1","1.5","2","2.5","3","3.5","4","4.5","5","5.5","6","6.5","7","7.5","8","8.5","9");
		Hours_spend.setLayoutX(450); Hours_spend.setLayoutY(320);
		
		Activity.getItems().addAll("Classroom Instruction","Supervised Study Hall","Assessments & Grading","labs","QA Reviews","Marketing","General","Holiday"
				                  ,"Vaccation","Sick","COntribution to the Discipline","Research/PhD Studies(others)","Professional Development",
				                  "Program Updates/Improvement","Community Services");
		Activity.setLayoutX(450); Activity.setLayoutY(360);
		
		Graded_What.getItems().addAll("ENb","No Grading","ANB","PNB","Student Effort Log","Tests","Project 1","Project 2","Project 3","Project 4",
				"Project 5","Project 6","Project 7","Project 8","Project 9"," Project 10");
		Graded_What.setLayoutX(450); Graded_What.setLayoutY(400);
			
		Deliverable_Type.getItems().addAll("Documentation/Presentation","Screencast","Spreadshet","Code");
		Deliverable_Type.setLayoutX(450); Deliverable_Type.setLayoutY(440);
		
		
		setupButtonUI(btn_SaveRecord, "Arial", 24,130,600);
		btn_SaveRecord.setEffect(ds);
		
		btn_SaveRecord.setOnAction((event) -> {String nameOfFaculty = text_Faculty.getText().toString();
		
		String staffId = text_StaffId.getText().toString();
		String weekNo = text_WeekNo.getText().toString();
		String noOfFiles = text_NoOfFile.getText().toString();
		String size = text_Size.getText().toString();
		String courseName = Course_Name.getValue().toString();
		String hoursSpend = Hours_spend.getValue().toString();
		String deliverableType = Deliverable_Type.getValue().toString();
		String gradedWhat = Graded_What.getValue().toString();
		String activityDone = Activity.getValue().toString();
		String date = datePicker.getValue().toString();

		//Creating a new work book
          XSSFWorkbook wb = new XSSFWorkbook();

		// Creating a new Blank Sheet
		XSSFSheet spreadsheet = wb.createSheet("Employee Info");

      	XSSFRow row;

		TreeMap<String, Object[]>empinfo = new TreeMap <String, Object[] > ();

		empinfo.put("Faculyt Name",  new Object[] {nameOfFaculty });
		empinfo.put("Staff Id", new Object[] {staffId});
		empinfo.put("Week No", new Object[] {weekNo});
	    empinfo.put("Size",  new Object[] {size });
	    empinfo.put("No Of files",  new Object[] {noOfFiles });
	    empinfo.put("Course Name",  new Object[] {courseName });
	    empinfo.put("hours Spend",  new Object[] {hoursSpend});
	    empinfo.put("Deliverbale Type",  new Object[] {deliverableType });
	    empinfo.put("Grade What",  new Object[] {gradedWhat });
	    empinfo.put("Activity DOne",  new Object[] {activityDone });
	    empinfo.put("Date",  new Object[] {date });
	    
	    // staring of iteration of data and write it in a deiretory 
	    Set <String> S1 = empinfo.keySet();           
	    int rowid= 1;

	    for (String S: S1)
	    {
	    	row = spreadsheet.createRow(rowid++);
	    	Object [] obj = empinfo.get(S);
	    	int cellid= 1;

	    	for(Object m : obj)
	    	{
	    		XSSFCell cell = row.createCell(cellid++);
	    		cell.setCellValue((String)m);
	    	}
	    }

	    // write it on a workbook on a file system
	    FileOutputStream out = null;
		try {
			out = new FileOutputStream(new File("D:\\Semester - 2\\App Development\\eclipse-workspace\\facultyeffort.xlsx"));
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
	    try {
			wb.write(out);
		} catch (IOException e) {
			
			e.printStackTrace();
		};
	    try {
			out.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	    System.out.println("File Created Succesfully....!!!!"); });
		
		
		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(lblHead,lblCourse,lblWeekNo,datePicker,Course_Name,Hours_spend,Activity,Graded_What,Deliverable_Type,
				lblFaculty,lblHours,lblNoOfFile,lblStaffId,lblSize,lblDay,lblDeliverableType,lblActivity,lblGradedWhat,text_Size,text_NoOfFile,
				text_WeekNo,text_Day,text_Faculty,text_StaffId,btn_SaveRecord,btn_Back,logo_imView);
}
	
	
	 /**********
      * Private local method to initialize the standard fields for a label
	  */
		private void setupLabelUI(Label l,String n, String ff, double f, double x, double y){
			l.setText(n);
			l.setFont(Font.font(ff, f));
			l.setLayoutX(x);
			l.setLayoutY(y);		
		}
		
		/**********
		 * Private local method to initialize the standard fields for a text field / password field
		 */
		private void setupTextUI(TextField t, String ff, double f, double w, double x, double y, boolean e){
			t.setFont(Font.font(ff, f));
			t.setMinWidth(w);
			t.setMaxWidth(w);
			t.setLayoutX(x);
			t.setLayoutY(y);		
			t.setEditable(e);
		}
	
		
		private void setupButtonUI(Button t, String ff, double f, double x, double y){
			t.setFont(Font.font(ff, f));
			t.setLayoutX(x);
			t.setLayoutY(y);		
		}
	
						
			public void saveRecordAction() {
		
			btn_SaveRecord.setOnAction(new EventHandler<ActionEvent>() {

	            public void handle(ActionEvent arg0) {
	            File File = new File("D:\\Semester - 2\\App Development\\eclipse-workspace\\facultyeffort.xlsx");
	             
	             if (File.exists())
	                {
	               	 if (Desktop.isDesktopSupported())
	                    {
	     
	             try {
	                Desktop.getDesktop().open(File);
	               }
	              catch (IOException e)
	                   {
	                    e.printStackTrace();
	                        }
	                      }
	                    }
	                    else
	                         {
	                 System.out.println("File is not exists!");
	                          }
	                       }
	                   });
		}
}
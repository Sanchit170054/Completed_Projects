Bootstrap 4 Portfolio Theme for Developers

Theme name:
=======================================================================
Developer

Theme version:
=======================================================================
v2.0

Release Date:
=======================================================================
17 July 2018

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (https://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: https://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/

If you'd like to use the template without the attribution, you can check out our commercial license options via our website: https://themes.3rdwavemedia.com/

import math

t_value = float(input("Enter your t-value here: "))
df = float(input("Enter your degree of freedom: "))
n_value = 200
deltaValue = (float(t_value)-0)/float(n_value);

x_values = {}
x_values[0] = 0 + deltaValue

for i in range(0, int(n_value)):
    x_values[i+1] = x_values[i] + deltaValue

x_square = {}
for i in x_values:
    x_square[i+1] = x_values[i]**2

gammaValueUpper = math.gamma((df+1)/2)
gammaValueLower = (math.sqrt(df*math.pi))*(math.gamma(df/2))

gammaValue = gammaValueUpper/gammaValueLower

pdfValues = {}

for i in range(1, len(x_square)-1):
    pdfValues[i] = gammaValue*math.pow(1+(x_square[i]/df), -1/2*(df+1))

totalValue = 0
for i in pdfValues:

    if(i % 2) == 0:
        totalValue = totalValue+pdfValues[i]*2
    else:
        totalValue = totalValue+pdfValues[i]*4

first_element = gammaValue*math.pow(1+(0/df), -1/2*(df+1))
last_element = gammaValue*math.pow(1+(x_square[len(x_square)-1]/df), -1/2*(df+1))

finalTotal = totalValue + first_element*1 + last_element*1

print("\nProbability of Left Side: {}".format(finalTotal*(deltaValue/3)))
print("Probability of double Side: {}".format(finalTotal*(deltaValue/3)+0.5))




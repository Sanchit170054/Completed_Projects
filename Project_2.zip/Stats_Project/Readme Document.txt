---------------------Read before Run program----------------

To verify output of the programs, there is excel file name as "calculator" where 
you can enter your values and compare the output of probability through programs and in excel file.



Team Members: -
1. Sanchit (170054)
2. Ujjwal (170021)
3. Saksham (170042)
4. Nipun (170028)
5. Mansi (170052)
6. Aastik (170024)
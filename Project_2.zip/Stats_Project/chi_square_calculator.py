import math

df = float(input("Enter your degree of freedom: "))
significanceLevel = float(input("Enter your significance Level here: "))

n_value = 200
deltaValue = (float(significanceLevel)-0)/float(n_value);

x_values = {}
x_values[0] = 0 + deltaValue

for i in range(0, int(n_value)):
    x_values[i+1] = x_values[i] + deltaValue

pdf_value = {}
for i in range(0, len(x_values)-2):
    pdf_value[i] = (1/((math.pow(2, df/2))*(math.gamma(df/2))))*math.pow(x_values[i], (df/2)-1)*math.pow(math.e, -(x_values[i]/2))


totalValue = 0
for i in pdf_value:
    if(i % 2) == 0:
        totalValue = totalValue + pdf_value[i]*4
    else:
        totalValue = totalValue + pdf_value[i]*2

firstElemet = ((1/((math.pow(2, df/2))*(math.gamma(df/2))))*math.pow(0, (df/2)-1)*math.pow(math.e, -(0/2)))
lastElement = ((1/((math.pow(2, df/2))*(math.gamma(df/2))))*math.pow(x_values[len(x_values)-1], (df/2)-1)*math.pow(math.e, -(x_values[len(x_values)-1]/2)))

finalTotal = totalValue + firstElemet*1 + lastElement*1
print("\nProbability of : {}".format(finalTotal*(deltaValue/3)))
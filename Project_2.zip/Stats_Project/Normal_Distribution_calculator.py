import math

z_value = float(input("Enter your Z-Score value here: "))
n_value = 100
deltaValue = (float(z_value)-0)/float(n_value);

x_values = {}
x_values[0] = 0 + deltaValue

for i in range(0, int(n_value)):
    x_values[i+1] = x_values[i] + deltaValue

x_square = {}
for i in x_values:
    x_square[i+1] = x_values[i]**2

pdf_value = {}
for i in range(1, len(x_square)-1):
    pdf_value[i] = 1/math.sqrt(2*math.pi)*math.pow(math.e, -1/2*x_square[i])

totalValue = 0
for i in pdf_value:
    if(i % 2) == 0:
        totalValue = totalValue+pdf_value[i]*2
    else:
        totalValue = totalValue+pdf_value[i]*4

firstElement = 1/math.sqrt(2*math.pi)*math.pow(math.e, -1/2*0)
lastElement = 1/math.sqrt(2*math.pi)*math.pow(math.e, -1/2*x_square[len(x_square)-1])

finalTotal = totalValue + firstElement*1 + lastElement*1

print("\nProbability of Left Side: {}".format(finalTotal*(deltaValue/3)))
print("Probability of double Side: {}".format(finalTotal*(deltaValue/3)+0.5))
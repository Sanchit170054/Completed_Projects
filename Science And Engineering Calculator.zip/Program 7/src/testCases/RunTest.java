package testCases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import calculator.BusinessLogic;
import calculator.CalculatorValue;


public class RunTest {
	
	/* This is the link to the business logic */
	public BusinessLogic perform = new BusinessLogic();
	CalculatorValue testcase_result;
	

	  @Test
	    public void testEvenOddNumber(){

		    testcase_result = new CalculatorValue("10");                  // It displays the value of operand1.
		    CalculatorValue value2 = new CalculatorValue("2");
		    testcase_result.mpy(value2);                                     // Here this means that the operand2 is subtracted from operand1.
		
		    //check for not null value
		    assertNotNull(testcase_result);
	    }
	

}


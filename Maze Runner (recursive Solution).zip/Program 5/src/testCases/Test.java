package testCases;
import org.junit.runner.JUnitCore;

import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import mazeRunnerRecursive.Maze;

public class Test 
{
	public static void main(String[] args) 
	{
		Result finalResult = JUnitCore.runClasses(Maze.class);
	    for (Failure Fail : finalResult.getFailures()) 
	    {
	    	System.out.println(Fail.toString());
	    }
	    	System.out.println(finalResult.wasSuccessful());
	}
}

package testCases;


import static org.junit.Assert.assertEquals;

import org.junit.Test;

import mazeRunnerRecursive.Maze;



public class RunTest {
	

	  @Test
	    public void testTheMethodAdd(){
		    boolean ans = false;
	        boolean val;
	        double num= 6;
	        Maze oddEven = new Maze(num, num);
	        
	        val = oddEven.makeMove(13, 5); 

	        assertEquals(ans,val);
	    }
	
}

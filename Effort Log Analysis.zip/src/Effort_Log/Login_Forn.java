package Effort_Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
//import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Login_Forn extends Application{
	
	TextField txtUserId = new TextField();
	PasswordField txtPass = new PasswordField();
	Label lblMessage = new Label();
	DropShadow ds = new DropShadow();
	public UserInterface theGUI;
	
	public final static double WINDOW_WIDTH = 800;
	public final static double WINDOW_HEIGHT = 600;
	//DatePicker datePicker = new DatePicker();
	

	public void UInterface(Pane theRoot) throws FileNotFoundException
	{	
		
       	
		Label lblHead = new Label("Login Form");
		
		Label lblUserId = new Label("User Id");
		Label lblPass = new Label("Password");
		
		Image img = new Image(new FileInputStream("mmu.jpg"));
		ImageView imView = new ImageView(img);
		
		imView.setLayoutX(0);       imView.setLayoutY(0);
		imView.setFitHeight(120);    imView.setFitWidth(120);
		
		ds.setOffsetY(3.0f);
		ds.setColor(Color.color(0.4f, 0.4f, 0.4f));
		
		Button btnSubmit = new Button("Submit");
		Button btnExit = new Button("Cancel");
		
				
		lblHead.setLayoutX(230); lblHead.setLayoutY(80);
		lblHead.setFont(Font.font("Arial",24));
		lblHead.setEffect(ds);
		
		lblUserId.setLayoutX(100); lblUserId.setLayoutY(150);
		lblUserId.setFont(Font.font("Arial",20));
		lblUserId.setEffect(ds);
		
		lblPass.setLayoutX(100); lblPass.setLayoutY(200);
		lblPass.setFont(Font.font("Arial",20));
		lblPass.setEffect(ds);
		
		txtUserId.setLayoutX(200); txtUserId.setLayoutY(150);
		txtPass.setLayoutX(200); txtPass.setLayoutY(200);
		
		btnSubmit.setLayoutX(150); btnSubmit.setLayoutY(250);
		btnSubmit.setFont(Font.font("Arial",20));
		btnSubmit.setOnAction((event) -> { submitAction(); });
		btnSubmit.setEffect(ds);
		
		btnExit.setLayoutX(350); btnExit.setLayoutY(250);
		btnExit.setFont(Font.font("Arial",20));
		btnExit.setOnAction((event) -> { System.exit(0); });
		btnExit.setEffect(ds);
		
		lblMessage.setLayoutX(200); lblMessage.setLayoutY(300);
		lblMessage.setFont(Font.font("Arial",24));
		
		//datePicker.setLayoutX(200); datePicker.setLayoutY(250);
		
		//datePicker.setOnAction((event) -> { datePickerAction(); });
		
		theRoot.getChildren().addAll(lblHead, lblUserId,lblPass,txtUserId,txtPass,
                btnSubmit,btnExit,lblMessage,imView);
		//,datePicker);
		//,);
	}
	
	
	@Override 
	   public void start(Stage stage) {
		
		stage.setTitle("Login Form");			// Label the stage (a window)
		
		Pane theRoot = new Pane();
		
        try {
			UInterface(theRoot);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(theRoot,600,400); //Creating a scene object
	     
		stage.setScene(scene);    //Adding scene to the stage 
	      
	     stage.show();            //Displaying the contents of the stage
	}
	
	
	
	 public static void main(String args[]){ 
	      launch(args); 
	   } 
	
	
	
	
	public void submitAction() {
		
		String checkUser = txtUserId.getText().toString();
		String  checkPw = txtPass.getText().toString();
		
		if(checkUser.equals("Sanchit") && checkPw.equals("2018")){
		      lblMessage.setText("Congratulations!");
		      lblMessage.setTextFill(Color.GREEN);
		      
		      Stage theStage = new Stage();
		      		      
		      theStage.setTitle("Sanchit & Pratik's:   Project 3");	
				 new Pane(new Group());
					
				// Create a pane within the window..............
				 
				 Pane theRoot = new Pane();						
				ListView<String> lv= new ListView<>();
				Pane root = new Pane(lv);
				
				// Create the Graphical User Interface................
				
				theGUI = new UserInterface(theRoot);				
				
				// Create the scene....................
				
				Scene theScene = new Scene(theRoot, WINDOW_WIDTH, WINDOW_HEIGHT);	
				  Scene sc= new Scene(root, 700, 600);
			   
				// Set the scene on the stage................
				  
				  theStage.setScene(sc);						
				((Pane) sc.getRoot()).getChildren().add(theScene.getRoot());
				
				// Show the stage to the user...................
				
				theStage.show();										
				
				// When the stage is shown to the user, the pane within the window is visible.  This means that the
				// labels, fields, and buttons of the Graphical User Interface (GUI) are visible//
			}
		else{
		    lblMessage.setText("Invalid User Id or Password.");
		    lblMessage.setTextFill(Color.RED);
		    }
		
	} 
}
